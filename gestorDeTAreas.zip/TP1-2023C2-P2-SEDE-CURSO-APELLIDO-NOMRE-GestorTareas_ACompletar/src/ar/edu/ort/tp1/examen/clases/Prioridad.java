package ar.edu.ort.tp1.examen.clases;

public enum Prioridad {

	ALTA, MEDIA, BAJA;
}
